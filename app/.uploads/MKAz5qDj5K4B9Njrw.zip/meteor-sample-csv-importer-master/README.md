# Sample meteor CSV upload and import 

Thanks to Ryan Glover - <a href="http://themeteorchef.com/">The Meteor Chef</a> for the help in debugging and fixing the bugs.

<p>The original source is from George Mcknight <a href="https://youtu.be/arutBQUi1bc" target="_blank">Youtube</a> Meteor Upload and Import CSV tutorial. </p>

<p>Feel free to clone this repo for your own use.</p>

<p><strong>Bug</strong>: Nothing happens if you click the "choose file" button on Firefox 38 running on Ubuntu 14.04 and Windows 7 but working as expected on Chromium Ubuntu 14.04 and Windows 7. Not sure on OS X.</p>

<p>If you happen to encounter the bug, please post it on issues, so that others can contribute and hopefully someone will fixed it.</p>

<p><strong>Disclaimer:</strong> I am not the author of the code, credits to George Mcknight as he is the source and Ryan Glover for fixing significant bugs.</p>

<p>Thanks and Happy coding!</p>